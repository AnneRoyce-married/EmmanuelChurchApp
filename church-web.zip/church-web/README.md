Church Web App - Starter (Vite + React + Tailwind CSS v4 + shadcn placeholders)

How to run:
1. npm install
2. npm run dev