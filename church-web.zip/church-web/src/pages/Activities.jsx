import React from 'react'

const activities = [
  {title: 'Sunday Worship', time: 'Sundays 10:00 AM'},
  {title: 'Youth Group', time: 'Fridays 6:00 PM'},
  {title: 'Food Bank', time: 'Monthly — 2nd Saturday'}
]

export default function Activities(){
  return (
    <main className="max-w-6xl mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold text-primary">Activities</h2>
      <ul className="mt-6 space-y-4">
        {activities.map(a => (
          <li key={a.title} className="p-4 bg-white rounded-lg shadow-sm flex justify-between">
            <div>
              <div className="font-semibold">{a.title}</div>
              <div className="text-sm text-gray-600">{a.time}</div>
            </div>
            <div className="text-sm text-gold font-semibold">Join</div>
          </li>
        ))}
      </ul>
    </main>
  )
}
