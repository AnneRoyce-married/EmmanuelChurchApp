import React from 'react'

const beliefs = [
  {title: 'The Bible', body: 'We believe the Bible is the inspired Word of God.'},
  {title: 'Jesus Christ', body: 'We believe in the deity and resurrection of Jesus Christ.'},
  {title: 'The Holy Spirit', body: 'We believe in the person and work of the Holy Spirit.'}
]

export default function Beliefs(){
  return (
    <main className="max-w-6xl mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold text-primary">Our Beliefs</h2>
      <div className="mt-6 grid md:grid-cols-3 gap-6">
        {beliefs.map((b)=> (
          <div key={b.title} className="p-6 bg-white rounded-lg shadow-sm">
            <h3 className="font-semibold">{b.title}</h3>
            <p className="mt-2 text-gray-600">{b.body}</p>
          </div>
        ))}
      </div>
    </main>
  )
}
