import React from 'react'
import Hero from '@/components/Hero'

export default function Home(){
  return (
    <main>
      <Hero />
      <section className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="p-6 bg-white rounded-lg shadow-sm">
            <h4 className="font-semibold text-primary">About Us</h4>
            <p className="mt-2 text-gray-600">A short paragraph giving an overview about the church.</p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-sm">
            <h4 className="font-semibold text-primary">Service Times</h4>
            <p className="mt-2 text-gray-600">Sunday 10:00 AM • Midweek Prayer Wednesday 7:30 PM</p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-sm">
            <h4 className="font-semibold text-primary">Get Involved</h4>
            <p className="mt-2 text-gray-600">Small groups, youth, outreach — find your place.</p>
          </div>
        </div>
      </section>
    </main>
  )
}
